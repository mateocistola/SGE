﻿using SGE.Aplicacion.Autorizacion;
using SGE.Aplicacion.Comun;
using SGE.Aplicacion.Expedientes;
using SGE.Aplicacion.Tramites;
using SGE.Aplicacion.Tramites.DTOs;
using SGE.Dominio.Comun;
using SGE.Dominio.Expedientes;
using SGE.Dominio.Tramites;
using SGE.Infraestructura.Autorizacion;
using SGE.Infraestructura.Comun;
using SGE.Infraestructura.Expedientes;
using SGE.Infraestructura.Tramites;

IExpedienteRepository expedienteRepository =
    new ExpedienteTxtRepository("Datos/expedientes.txt");

ITramiteRepository tramiteRepository =
    new TramiteTxtRepository("Datos/tramites.txt");

IAutorizacionService autorizacionService =
    new AutorizacionProvisionalService();

var actualizacionEstadoExpedienteService =
    new ActualizacionEstadoExpedienteService(
        expedienteRepository,
        tramiteRepository
    );

var agregarExpedienteUseCase =
    new AgregarExpedienteUseCase(
        expedienteRepository,
        autorizacionService
    );

var listarExpedientesUseCase =
    new ListarExpedientesUseCase(
        expedienteRepository
    );

var modificarCaratulaExpedienteUseCase =
    new ModificarCaratulaExpedienteUseCase(
        expedienteRepository,
        autorizacionService
    );

var cambiarEstadoExpedienteUseCase =
    new CambiarEstadoExpedienteUseCase(
        expedienteRepository,
        autorizacionService
    );

var eliminarExpedienteUseCase =
    new EliminarExpedienteUseCase(
        expedienteRepository,
        tramiteRepository,
        autorizacionService
    );

var agregarTramiteUseCase =
    new AgregarTramiteUseCase(
        tramiteRepository,
        autorizacionService,
        actualizacionEstadoExpedienteService
    );

var listarTramitesPorExpedienteUseCase =
    new ListarTramitesPorExpedienteUseCase(
        tramiteRepository,
        expedienteRepository
    );

var modificarTramiteUseCase =
    new ModificarTramiteUseCase(
        tramiteRepository,
        autorizacionService,
        actualizacionEstadoExpedienteService
    );

var eliminarTramiteUseCase =
    new EliminarTramiteUseCase(
        tramiteRepository,
        autorizacionService,
        actualizacionEstadoExpedienteService
    );

Guid idUsuario = Guid.NewGuid();

bool salir = false;

while (!salir)
{
    MostrarMenu();

    Console.Write("Seleccione una opción: ");
    string? opcion = Console.ReadLine();

    Console.WriteLine();

    try
    {
        switch (opcion)
        {
            case "1":
                CrearExpediente();
                break;

            case "2":
                ListarExpedientes();
                break;

            case "3":
                ModificarCaratula();
                break;

            case "4":
                CambiarEstado();
                break;

            case "5":
                EliminarExpediente();
                break;

            case "6":
                AgregarTramite();
                break;

            case "7":
                ListarTramitesPorExpediente();
                break;

            case "8":
                ModificarTramite();
                break;

            case "9":
                EliminarTramite();
                break;

            case "0":
                salir = true;
                Console.WriteLine("Saliendo del sistema...");
                break;

            default:
                Console.WriteLine("Opción inválida.");
                break;
        }
    }
    catch (AutorizacionException ex)
    {
        Console.WriteLine($"Error de autorización: {ex.Message}");
    }
    catch (DominioException ex)
    {
        Console.WriteLine($"Error de dominio: {ex.Message}");
    }
    catch (EntidadNoEncontradaException ex)
    {
        Console.WriteLine($"Entidad no encontrada: {ex.Message}");
    }
    catch (SGE.Aplicacion.Comun.RepositorioException ex)
    {
        Console.WriteLine($"Error de repositorio: {ex.Message}");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Error inesperado: {ex.Message}");
    }

    Console.WriteLine();
    Console.WriteLine("Presione ENTER para continuar...");
    Console.ReadLine();
    Console.Clear();
}

void MostrarMenu()
{
    Console.WriteLine("=== SGE - Sistema de Gestión de Expedientes ===");
    Console.WriteLine();
    Console.WriteLine("1. Crear expediente");
    Console.WriteLine("2. Listar expedientes");
    Console.WriteLine("3. Modificar carátula de expediente");
    Console.WriteLine("4. Cambiar estado de expediente");
    Console.WriteLine("5. Eliminar expediente");
    Console.WriteLine("6. Agregar trámite");
    Console.WriteLine("7. Listar trámites por expediente");
    Console.WriteLine("8. Modificar trámite");
    Console.WriteLine("9. Eliminar trámite");
    Console.WriteLine("0. Salir");
    Console.WriteLine();
}

void CrearExpediente()
{
    Console.Write("Ingrese carátula: ");
    string caratula = Console.ReadLine() ?? "";

    var response = agregarExpedienteUseCase.Ejecutar(
        new AgregarExpedienteRequest(
            caratula,
            idUsuario
        )
    );

    Console.WriteLine($"Expediente creado correctamente. Id: {response.Id}");
}

void ListarExpedientes()
{
    var response = listarExpedientesUseCase.Ejecutar();

    Console.WriteLine("=== Expedientes ===");

    foreach (var expediente in response.Expedientes)
    {
        Console.WriteLine($"Id: {expediente.Id}");
        Console.WriteLine($"Carátula: {expediente.Caratula}");
        Console.WriteLine($"Estado: {expediente.Estado}");
        Console.WriteLine($"Fecha creación: {expediente.FechaCreacion}");
        Console.WriteLine("-----------------------------------");
    }
}

void ModificarCaratula()
{
    Guid expedienteId = LeerGuid("Ingrese Id del expediente: ");

    Console.Write("Ingrese nueva carátula: ");
    string nuevaCaratula = Console.ReadLine() ?? "";

    modificarCaratulaExpedienteUseCase.Ejecutar(
        new ModificarCaratulaExpedienteRequest(
            expedienteId,
            nuevaCaratula,
            idUsuario
        )
    );

    Console.WriteLine("Carátula modificada correctamente.");
}

void CambiarEstado()
{
    Guid expedienteId = LeerGuid("Ingrese Id del expediente: ");

    Console.WriteLine("Estados disponibles:");
    foreach (var estado in Enum.GetValues<EstadoExpediente>())
    {
        Console.WriteLine($"- {estado}");
    }

    Console.Write("Ingrese nuevo estado: ");
    string? estadoTexto = Console.ReadLine();

    if (!Enum.TryParse<EstadoExpediente>(estadoTexto, out var nuevoEstado))
    {
        Console.WriteLine("Estado inválido.");
        return;
    }

    cambiarEstadoExpedienteUseCase.Ejecutar(
        new CambiarEstadoExpedienteRequest(
            expedienteId,
            nuevoEstado,
            idUsuario
        )
    );

    Console.WriteLine("Estado modificado correctamente.");
}

void EliminarExpediente()
{
    Guid expedienteId = LeerGuid("Ingrese Id del expediente a eliminar: ");

    eliminarExpedienteUseCase.Ejecutar(
        new EliminarExpedienteRequest(
            expedienteId,
            idUsuario
        )
    );

    Console.WriteLine("Expediente eliminado correctamente.");
}

void AgregarTramite()
{
    Guid expedienteId = LeerGuid("Ingrese Id del expediente: ");

    Console.WriteLine("Etiquetas disponibles:");
    foreach (var etiquetaDisp in Enum.GetValues<EtiquetaTramite>())
    {
        Console.WriteLine($"- {etiquetaDisp}");
    }

    Console.Write("Ingrese etiqueta: ");
    string? etiquetaTexto = Console.ReadLine();

    if (!Enum.TryParse<EtiquetaTramite>(etiquetaTexto, out var etiqueta))
    {
        Console.WriteLine("Etiqueta inválida.");
        return;
    }

    Console.Write("Ingrese contenido del trámite: ");
    string contenido = Console.ReadLine() ?? "";

    var response = agregarTramiteUseCase.Ejecutar(
        new AgregarTramiteRequest(
            expedienteId,
            etiqueta,
            contenido,
            idUsuario
        )
    );

    Console.WriteLine($"Trámite creado correctamente. Id: {response.Id}");
}

void ListarTramitesPorExpediente()
{
    Guid expedienteId = LeerGuid("Ingrese Id del expediente: ");

    var response = listarTramitesPorExpedienteUseCase.Ejecutar(
        new ListarTramitesPorExpedienteRequest(expedienteId)
    );

    Console.WriteLine("=== Trámites ===");

    foreach (var tramite in response.Tramites)
    {
        Console.WriteLine($"Id: {tramite.Id}");
        Console.WriteLine($"Etiqueta: {tramite.Etiqueta}");
        Console.WriteLine($"Contenido: {tramite.Contenido}");
        Console.WriteLine($"Fecha creación: {tramite.FechaCreacion}");
        Console.WriteLine("-----------------------------------");
    }
}

void ModificarTramite()
{
    Guid tramiteId = LeerGuid("Ingrese Id del trámite: ");

    Console.WriteLine("Etiquetas disponibles:");
    foreach (var etiquetaDisp in Enum.GetValues<EtiquetaTramite>())
    {
        Console.WriteLine($"- {etiquetaDisp}");
    }

    Console.Write("Ingrese nueva etiqueta: ");
    string? etiquetaTexto = Console.ReadLine();

    if (!Enum.TryParse<EtiquetaTramite>(etiquetaTexto, out var etiqueta))
    {
        Console.WriteLine("Etiqueta inválida.");
        return;
    }

    Console.Write("Ingrese nuevo contenido: ");
    string contenido = Console.ReadLine() ?? "";

    modificarTramiteUseCase.Ejecutar(
        new ModificarTramiteRequest(
            tramiteId,
            etiqueta,
            contenido,
            idUsuario
        )
    );

    Console.WriteLine("Trámite modificado correctamente.");
}

void EliminarTramite()
{
    Guid tramiteId = LeerGuid("Ingrese Id del trámite a eliminar: ");

    eliminarTramiteUseCase.Ejecutar(
        new EliminarTramiteRequest(
            tramiteId,
            idUsuario
        )
    );

    Console.WriteLine("Trámite eliminado correctamente.");
}

Guid LeerGuid(string mensaje)
{
    while (true)
    {
        Console.Write(mensaje);
        string? texto = Console.ReadLine();

        if (Guid.TryParse(texto, out Guid id))
        {
            return id;
        }

        Console.WriteLine("El Id ingresado no es válido. Intente nuevamente.");
    }
}